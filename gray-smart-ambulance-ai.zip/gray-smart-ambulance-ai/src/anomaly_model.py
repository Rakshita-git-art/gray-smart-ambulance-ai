import pandas as pd
import numpy as np
from sklearn.ensemble import IsolationForest

class AnomalyDetector:
    def __init__(self):
        self.model = IsolationForest(contamination=0.05, random_state=42)

    def train(self, df):
        features = df[["HR", "SpO2", "SysBP", "DiaBP"]]
        self.model.fit(features)

    def predict(self, df):
        features = df[["HR", "SpO2", "SysBP", "DiaBP"]]
        preds = self.model.predict(features)
        return np.where(preds == -1, 1, 0)

if __name__ == "__main__":
    df = pd.read_csv("data/processed/patient_01_clean.csv")
    detector = AnomalyDetector()
    detector.train(df)
    df["anomaly"] = detector.predict(df)
    df.to_csv("data/processed/patient_01_anomaly.csv", index=False)
    print("✅ Anomaly detection completed")
