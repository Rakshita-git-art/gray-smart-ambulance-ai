import pandas as pd
import numpy as np
from sklearn.metrics import precision_score, recall_score

def evaluate_alerts(csv_path):
    df = pd.read_csv(csv_path)

    # Ground truth labels & model predictions
    y_true = df["true_label"]
    y_pred = df["predicted_label"]

    precision = precision_score(y_true, y_pred)
    recall = recall_score(y_true, y_pred)

    # False Alert Rate
    false_alerts = ((y_pred == 1) & (y_true == 0)).sum()
    normal_cases = (y_true == 0).sum()
    false_alert_rate = false_alerts / normal_cases

    # Alert latency
    latency_list = []

    distress_indexes = df[df["true_label"] == 1].index.tolist()

    for idx in distress_indexes:
        pred_idx = df[(df.index >= idx) & (df["predicted_label"] == 1)].index
        if len(pred_idx) > 0:
            latency_list.append(pred_idx[0] - idx)

    avg_latency = np.mean(latency_list) if latency_list else None

    return {
        "Precision": round(precision, 3),
        "Recall": round(recall, 3),
        "False Alert Rate": round(false_alert_rate, 3),
        "Alert Latency (sec)": avg_latency
    }

if __name__ == "__main__":
    results = evaluate_alerts("data/processed/patient_01_anomaly.csv")
    print("\n--- Alert Quality Evaluation ---")
    for k, v in results.items():
        print(f"{k}: {v}")
