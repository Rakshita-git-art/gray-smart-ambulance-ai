import numpy as np

NORMAL_RANGES = {
    "HR": (60, 100),
    "SpO2": (95, 100),
    "SysBP": (100, 130),
    "DiaBP": (60, 90)
}

def compute_contributions(row):
    contributions = {}

    for key, (low, high) in NORMAL_RANGES.items():
        val = row[key]

        if val < low:
            contrib = (low - val) / low
        elif val > high:
            contrib = (val - high) / high
        else:
            contrib = 0

        contributions[key] = max(0, contrib)

    total = sum(contributions.values()) + 1e-6

    for k in contributions:
        contributions[k] = round(100 * contributions[k] / total, 2)

    return contributions
