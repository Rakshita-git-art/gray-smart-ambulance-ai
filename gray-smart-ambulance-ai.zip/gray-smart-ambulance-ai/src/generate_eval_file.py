import pandas as pd
from anomaly_model import AnomalyDetector

# Load cleaned data
df = pd.read_csv("data/processed/patient_01_clean.csv")

# -----------------------------
# Generate TRUE labels
# -----------------------------
# Simulated distress rule
df["true_label"] = (
    (df["HR"] > 120) |
    (df["SpO2"] < 90) |
    (df["SysBP"] < 90)
).astype(int)

# -----------------------------
# Train model
# -----------------------------
model = AnomalyDetector()
model.train(df)

# -----------------------------
# Predict labels
# -----------------------------
df["predicted_label"] = model.predict(df)

# -----------------------------
# Save evaluation file
# -----------------------------
df.to_csv("data/processed/patient_01_anomaly.csv", index=False)

print("patient_01_anomaly.csv created successfully")
