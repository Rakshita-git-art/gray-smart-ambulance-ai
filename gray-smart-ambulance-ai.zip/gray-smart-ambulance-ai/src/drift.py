import numpy as np

BASELINE_STATS = {
    "HR": {"mean": 80, "std": 10},
    "SpO2": {"mean": 98, "std": 1.5},
    "SysBP": {"mean": 120, "std": 10},
    "DiaBP": {"mean": 80, "std": 8}
}

def compute_drift(row):
    scores = []

    for key in BASELINE_STATS:
        mean = BASELINE_STATS[key]["mean"]
        std = BASELINE_STATS[key]["std"]

        val = row[key]
        z = abs((val - mean) / (std + 1e-6))
        scores.append(z)

    drift_score = np.mean(scores)

    return {
        "detected": bool(drift_score > 2.5),
        "drift_score": round(float(drift_score), 2)
    }
