import numpy as np

def compute_risk(row):
    score = 0

    if row["HR"] > 120: score += 30
    if row["SpO2"] < 92: score += 35
    if row["SysBP"] < 90: score += 25

    return min(score, 100)

def confidence_score(row):
    if row["Motion"] > 2:
        return 0.5
    return 0.9
