import pandas as pd
import numpy as np
from scipy.signal import medfilt

def remove_motion_artifacts(df):
    clean_df = df.copy()

    motion_thresh = 2.0
    artifact_idx = clean_df["Motion"] > motion_thresh

    clean_df.loc[artifact_idx, "SpO2"] = np.nan
    clean_df.loc[artifact_idx, "HR"] = np.nan

    clean_df["SpO2"] = clean_df["SpO2"].interpolate()
    clean_df["HR"] = clean_df["HR"].interpolate()

    clean_df["HR"] = medfilt(clean_df["HR"], kernel_size=5)
    clean_df["SpO2"] = medfilt(clean_df["SpO2"], kernel_size=5)

    return clean_df

if __name__ == "__main__":
    df = pd.read_csv("data/raw/patient_01.csv")
    clean = remove_motion_artifacts(df)
    clean.to_csv("data/processed/patient_01_clean.csv", index=False)
    print(" Artifacts cleaned")
