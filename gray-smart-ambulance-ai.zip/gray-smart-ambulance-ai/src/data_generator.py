import numpy as np
import pandas as pd

def generate_patient_data(duration_minutes=30, seed=42):
    np.random.seed(seed)
    total_seconds = duration_minutes * 60
    t = np.arange(total_seconds)

    hr = 75 + 5 * np.random.randn(total_seconds)
    spo2 = 98 + 1 * np.random.randn(total_seconds)
    sys_bp = 120 + 5 * np.random.randn(total_seconds)
    dia_bp = 80 + 4 * np.random.randn(total_seconds)

    motion = np.abs(np.random.randn(total_seconds)) * 0.3

    distress_start = 900
    distress_end = 1200

    hr[distress_start:distress_end] += np.linspace(0, 40, distress_end - distress_start)
    spo2[distress_start:distress_end] -= np.linspace(0, 8, distress_end - distress_start)
    sys_bp[distress_start:distress_end] -= np.linspace(0, 25, distress_end - distress_start)

    for i in range(6):
        idx = np.random.randint(200, total_seconds-200)
        motion[idx:idx+25] += 3
        spo2[idx:idx+25] -= np.random.uniform(5, 12)
        hr[idx:idx+25] += np.random.uniform(15, 30)

    df = pd.DataFrame({
    "time_sec": t,
    "HR": hr,
    "SpO2": spo2,
    "SysBP": sys_bp,
    "DiaBP": dia_bp,
    "Motion": motion
})

    return df

if __name__ == "__main__":
    df = generate_patient_data()
    df.to_csv("data/raw/patient_01.csv", index=False)
    print(" Data generated successfully")
