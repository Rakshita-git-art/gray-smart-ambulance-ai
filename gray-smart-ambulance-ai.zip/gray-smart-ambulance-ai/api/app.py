from fastapi import FastAPI
from pydantic import BaseModel
import pandas as pd

from src.anomaly_model import AnomalyDetector
from src.risk_scoring import compute_risk, confidence_score
from src.explainability import compute_contributions
from src.drift import compute_drift
from src.evaluation import evaluate_alerts

app = FastAPI()
model = AnomalyDetector()

class Vitals(BaseModel):
    HR: float
    SpO2: float
    SysBP: float
    DiaBP: float
    Motion: float

@app.on_event("startup")
def load_model():
    global eval_metrics

    # Train model
    df = pd.read_csv("data/processed/patient_01_clean.csv")
    model.train(df)

    # Load evaluation metrics
    eval_metrics = evaluate_alerts("data/processed/patient_01_anomaly.csv")

@app.post("/predict")
def predict(v: Vitals):
    df = pd.DataFrame([v.dict()])

    anomaly = model.predict(df)[0]
    risk = compute_risk(df.iloc[0])
    conf = confidence_score(df.iloc[0])
    explanation = compute_contributions(df.iloc[0])
    drift = compute_drift(df.iloc[0])

    return {
        "anomaly": int(anomaly),
        "risk_score": float(risk),
        "confidence": float(conf),
        "explanation": explanation,
        "drift": drift,
        "evaluation": eval_metrics
    }





