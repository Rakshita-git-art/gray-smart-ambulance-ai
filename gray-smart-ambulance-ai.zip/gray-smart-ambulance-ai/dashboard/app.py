import streamlit as st
import requests
import matplotlib.pyplot as plt

API_URL = "http://127.0.0.1:8000/predict"

st.set_page_config(page_title="Smart Ambulance AI Dashboard", layout="wide")

st.title("Smart Ambulance AI Live Monitoring System")
st.markdown("### Real-Time Patient Risk & Emergency Detection")


st.sidebar.header("Patient Vitals Input")

HR = st.sidebar.slider("Heart Rate", 30, 200, 80)
SpO2 = st.sidebar.slider("SpO2", 70, 100, 98)
SysBP = st.sidebar.slider("Systolic BP", 60, 200, 120)
DiaBP = st.sidebar.slider("Diastolic BP", 40, 150, 80)
Motion = st.sidebar.slider("Motion", 0.0, 5.0, 0.5)

payload = {
    "HR": HR,
    "SpO2": SpO2,
    "SysBP": SysBP,
    "DiaBP": DiaBP,
    "Motion": Motion
}

# -------- Prediction -------- #
if st.sidebar.button("Run AI Analysis"):

    response = requests.post(API_URL, json=payload)

    if response.status_code == 200:
        result = response.json()
        evaluation = result["evaluation"]


        col1, col2, col3 = st.columns(3)

        col1.metric("🧠 Anomaly", "YES 🚨" if result["anomaly"] == 1 else "NO ✅")
        col2.metric("🔥 Risk Score", result["risk_score"])
        col3.metric("📊 Confidence", result["confidence"])

        # -------- Alerts -------- #
        if result["risk_score"] > 80:
            st.error("🚨 CRITICAL PATIENT — IMMEDIATE ACTION REQUIRED")
        elif result["risk_score"] > 50:
            st.warning("⚠️ HIGH RISK — Monitor Closely")
        else:
            st.success("✅ Stable Patient")

                # -------- Evaluation Metrics -------- #
        st.subheader("📊 Model Alert Performance Metrics")

        m1, m2, m3, m4 = st.columns(4)

        m1.metric("Precision", evaluation["Precision"])
        m2.metric("Recall", evaluation["Recall"])
        m3.metric("False Alert Rate", evaluation["False Alert Rate"])
        m4.metric("Alert Latency (sec)", evaluation["Alert Latency (sec)"])


        # -------- Drift -------- #
        st.subheader("📉 Data Drift Monitoring")
        drift = result["drift"]

        if drift["detected"]:
            st.error(f"⚠️ Data Drift Detected | Score: {drift['drift_score']}")
        else:
            st.success(f"✅ No Drift | Score: {drift['drift_score']}")

        # -------- Explainability -------- #
        st.subheader("🧠 Explainable AI Output")

        features = list(result["explanation"].keys())
        values = list(result["explanation"].values())

        fig, ax = plt.subplots()
        ax.barh(features, values)
        ax.set_title("Feature Contribution to Risk")

        st.pyplot(fig)

    else:
        st.error("API Connection Failed")
